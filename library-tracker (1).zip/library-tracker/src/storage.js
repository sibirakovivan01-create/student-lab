const STORAGE_KEY = "library-tracker-books";

export function getBooks() {
  try {
    const rawData = localStorage.getItem(STORAGE_KEY);

    if (!rawData) {
      return [];
    }

    const parsedData = JSON.parse(rawData);

    if (!Array.isArray(parsedData)) {
      return [];
    }

    return parsedData;
  } catch (error) {
    console.error("Ошибка чтения localStorage:", error);
    return [];
  }
}

export function saveBooks(books) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
    return true;
  } catch (error) {
    console.error("Ошибка сохранения в localStorage:", error);
    return false;
  }
}

export function addBook(book) {
  const books = getBooks();

  books.push(book);

  return saveBooks(books);
}

export function updateBook(updatedBook) {
  const books = getBooks();

  const index = books.findIndex(
    (book) => book.id === updatedBook.id
  );

  if (index === -1) {
    return false;
  }

  books[index] = updatedBook;

  return saveBooks(books);
}

export function deleteBook(bookId) {
  const books = getBooks();

  const filteredBooks = books.filter(
    (book) => book.id !== bookId
  );

  return saveBooks(filteredBooks);
}

export function getBookById(bookId) {
  const books = getBooks();

  return books.find(
    (book) => book.id === bookId
  ) || null;
}

export function initializeStorage(demoBooks = []) {
  const existingBooks = localStorage.getItem(STORAGE_KEY);

  if (existingBooks === null && demoBooks.length > 0) {
    saveBooks(demoBooks);
  }
}