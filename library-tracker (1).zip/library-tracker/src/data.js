export const BOOK_STATUSES = {
  read: {
    value: "read",
    label: "Прочитано"
  },

  reading: {
    value: "reading",
    label: "Читаю сейчас"
  },

  planned: {
    value: "planned",
    label: "Запланировано"
  }
};

export const GENRES = [
  "Фантастика",
  "Фэнтези",
  "Детектив",
  "Триллер",
  "Роман",
  "Приключения",
  "История",
  "Биография",
  "Философия",
  "Психология",
  "Научпоп",
  "Классика",
  "Ужасы",
  "Драма",
  "Другое"
];

export const DEMO_BOOKS = [
  {
    id: crypto.randomUUID(),
    title: "Мастер и Маргарита",
    author: "Михаил Булгаков",
    genre: "Классика",
    pages: 480,
    progress: 100,
    status: "read",
    createdAt: Date.now() - 300000
  },

  {
    id: crypto.randomUUID(),
    title: "1984",
    author: "Джордж Оруэлл",
    genre: "Фантастика",
    pages: 328,
    progress: 67,
    status: "reading",
    createdAt: Date.now() - 200000
  },

  {
    id: crypto.randomUUID(),
    title: "Преступление и наказание",
    author: "Фёдор Достоевский",
    genre: "Классика",
    pages: 672,
    progress: 0,
    status: "planned",
    createdAt: Date.now() - 100000
  }
];