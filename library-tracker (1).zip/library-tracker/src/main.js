import "./style.css";

import {
  BOOK_STATUSES,
  DEMO_BOOKS
} from "./data.js";

import {
  getBooks,
  addBook,
  updateBook,
  deleteBook,
  getBookById,
  initializeStorage
} from "./storage.js";

import {
  populateGenres,
  populateGenreFilter,
  renderBooks,
  updateStatistics,
  fillBookForm,
  clearBookForm,
  updateProgressVisibility,
  openModal,
  closeModal,
  showToast
} from "./ui.js";

const elements = {
  addBookBtn: document.getElementById("addBookBtn"),

  bookModal: document.getElementById("bookModal"),
  closeModalBtn: document.getElementById("closeModalBtn"),
  cancelModalBtn: document.getElementById("cancelModalBtn"),

  modalTitle: document.getElementById("modalTitle"),

  bookForm: document.getElementById("bookForm"),
  bookId: document.getElementById("bookId"),
  bookTitle: document.getElementById("bookTitle"),
  bookAuthor: document.getElementById("bookAuthor"),
  bookGenre: document.getElementById("bookGenre"),
  bookPages: document.getElementById("bookPages"),
  bookStatus: document.getElementById("bookStatus"),
  bookProgress: document.getElementById("bookProgress"),
  progressValue: document.getElementById("progressValue"),
  progressGroup: document.getElementById("progressGroup"),

  searchInput: document.getElementById("searchInput"),
  genreFilter: document.getElementById("genreFilter"),
  resetFiltersBtn: document.getElementById("resetFiltersBtn"),

  totalBooks: document.getElementById("totalBooks"),
  readBooks: document.getElementById("readBooks"),
  averageProgress: document.getElementById("averageProgress"),

  booksCounter: document.getElementById("booksCounter"),

  readCount: document.getElementById("readCount"),
  readingCount: document.getElementById("readingCount"),
  plannedCount: document.getElementById("plannedCount"),

  readList: document.getElementById("readList"),
  readingList: document.getElementById("readingList"),
  plannedList: document.getElementById("plannedList"),

  emptyState: document.getElementById("emptyState")
};

let books = [];

let filters = {
  search: "",
  genre: "all"
};

let editingBookId = null;

initialize();

function initialize() {
  initializeStorage(DEMO_BOOKS);

  books = getBooks();

  populateGenres(elements.bookGenre);
  populateGenreFilter(elements.genreFilter);

  bindEvents();

  updateProgressVisibility(elements);

  render();
}

function bindEvents() {
  elements.addBookBtn.addEventListener(
    "click",
    handleAddBook
  );

  elements.closeModalBtn.addEventListener(
    "click",
    handleCloseModal
  );

  elements.cancelModalBtn.addEventListener(
    "click",
    handleCloseModal
  );

  elements.bookModal.addEventListener(
    "click",
    (event) => {
      if (
        event.target.matches("[data-close-modal]")
      ) {
        handleCloseModal();
      }
    }
  );

  elements.bookForm.addEventListener(
    "submit",
    handleFormSubmit
  );

  elements.bookStatus.addEventListener(
    "change",
    () => {
      updateProgressVisibility(elements);
    }
  );

  elements.bookProgress.addEventListener(
    "input",
    () => {
      elements.progressValue.textContent =
        `${elements.bookProgress.value}%`;
    }
  );

  elements.searchInput.addEventListener(
    "input",
    handleFiltersChange
  );

  elements.genreFilter.addEventListener(
    "change",
    handleFiltersChange
  );

  elements.resetFiltersBtn.addEventListener(
    "click",
    resetFilters
  );

  elements.readList.addEventListener(
    "click",
    handleBookAction
  );

  elements.readingList.addEventListener(
    "click",
    handleBookAction
  );

  elements.plannedList.addEventListener(
    "click",
    handleBookAction
  );

  document.addEventListener(
    "keydown",
    (event) => {
      if (
        event.key === "Escape" &&
        !elements.bookModal.classList.contains("hidden")
      ) {
        handleCloseModal();
      }
    }
  );
}

function handleAddBook() {
  editingBookId = null;

  clearBookForm(elements);

  openModal(elements, false);
}

function handleCloseModal() {
  closeModal(elements);

  editingBookId = null;

  clearBookForm(elements);
}

function handleFormSubmit(event) {
  event.preventDefault();

  const title =
    elements.bookTitle.value.trim();

  const author =
    elements.bookAuthor.value.trim();

  const genre =
    elements.bookGenre.value;

  const pages =
    Number(elements.bookPages.value);

  const status =
    elements.bookStatus.value;

  let progress =
    Number(elements.bookProgress.value);

  if (!title || !author || !genre) {
    showToast(
      "Заполните обязательные поля.",
      "error"
    );

    return;
  }

  if (!Number.isFinite(pages) || pages < 1) {
    showToast(
      "Количество страниц должно быть больше 0.",
      "error"
    );

    return;
  }

  if (!BOOK_STATUSES[status]) {
    showToast(
      "Выбран некорректный статус.",
      "error"
    );

    return;
  }

  if (status === "read") {
    progress = 100;
  }

  if (status === "planned") {
    progress = 0;
  }

  progress = Math.min(
    100,
    Math.max(0, progress)
  );

  if (editingBookId) {
    const existingBook =
      getBookById(editingBookId);

    if (!existingBook) {
      showToast(
        "Книга не найдена.",
        "error"
      );

      return;
    }

    const updatedBook = {
      ...existingBook,
      title,
      author,
      genre,
      pages,
      progress,
      status
    };

    if (!updateBook(updatedBook)) {
      showToast(
        "Не удалось сохранить изменения.",
        "error"
      );

      return;
    }

    showToast("Книга обновлена.");

  } else {
    const newBook = {
      id: crypto.randomUUID(),
      title,
      author,
      genre,
      pages,
      progress,
      status,
      createdAt: Date.now()
    };

    if (!addBook(newBook)) {
      showToast(
        "Не удалось сохранить книгу.",
        "error"
      );

      return;
    }

    showToast("Книга добавлена.");
  }

  books = getBooks();

  handleCloseModal();

  render();
}

function handleFiltersChange() {
  filters.search =
    elements.searchInput.value
      .trim()
      .toLowerCase();

  filters.genre =
    elements.genreFilter.value;

  render();
}

function resetFilters() {
  filters.search = "";
  filters.genre = "all";

  elements.searchInput.value = "";
  elements.genreFilter.value = "all";

  render();
}

function getFilteredBooks() {
  return books.filter((book) => {
    const searchableText =
      `${book.title} ${book.author}`
        .toLowerCase();

    const matchesSearch =
      !filters.search ||
      searchableText.includes(filters.search);

    const matchesGenre =
      filters.genre === "all" ||
      book.genre === filters.genre;

    return matchesSearch && matchesGenre;
  });
}

function handleBookAction(event) {
  const button =
    event.target.closest("[data-action]");

  if (!button) {
    return;
  }

  const card =
    button.closest(".book-card");

  if (!card) {
    return;
  }

  const bookId =
    card.dataset.bookId;

  const action =
    button.dataset.action;

  if (action === "edit") {
    handleEditBook(bookId);
  }

  if (action === "delete") {
    handleDeleteBook(bookId);
  }

  if (action === "status") {
    handleChangeStatus(bookId);
  }
}

function handleEditBook(bookId) {
  const book = getBookById(bookId);

  if (!book) {
    showToast(
      "Книга не найдена.",
      "error"
    );

    return;
  }

  editingBookId = bookId;

  fillBookForm(book, elements);

  openModal(elements, true);
}

function handleDeleteBook(bookId) {
  const book = getBookById(bookId);

  if (!book) {
    return;
  }

  const confirmed = window.confirm(
    `Удалить книгу «${book.title}»?`
  );

  if (!confirmed) {
    return;
  }

  if (!deleteBook(bookId)) {
    showToast(
      "Не удалось удалить книгу.",
      "error"
    );

    return;
  }

  books = getBooks();

  showToast("Книга удалена.");

  render();
}

function handleChangeStatus(bookId) {
  const book = getBookById(bookId);

  if (!book) {
    return;
  }

  const statusOrder = [
    "planned",
    "reading",
    "read"
  ];

  const currentIndex =
    statusOrder.indexOf(book.status);

  const nextIndex =
    (currentIndex + 1) %
    statusOrder.length;

  const nextStatus =
    statusOrder[nextIndex];

  let nextProgress =
    Number(book.progress || 0);

  if (nextStatus === "read") {
    nextProgress = 100;
  }

  if (nextStatus === "planned") {
    nextProgress = 0;
  }

  const updatedBook = {
    ...book,
    status: nextStatus,
    progress: nextProgress
  };

  if (!updateBook(updatedBook)) {
    showToast(
      "Не удалось изменить статус.",
      "error"
    );

    return;
  }

  books = getBooks();

  showToast(
    `Статус изменён: ${BOOK_STATUSES[nextStatus].label}.`
  );

  render();
}

function render() {
  const filteredBooks =
    getFilteredBooks();

  renderBooks(
    filteredBooks,
    elements
  );

  updateStatistics(
    books,
    elements
  );
}