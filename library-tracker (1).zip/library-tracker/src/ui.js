import { BOOK_STATUSES, GENRES } from "./data.js";

function escapeHTML(value) {
  const div = document.createElement("div");
  div.textContent = String(value ?? "");
  return div.innerHTML;
}

export function populateGenres(selectElement) {
  if (!selectElement) {
    return;
  }

  selectElement.innerHTML = `
    <option value="">ВЫБЕРИТЕ ЖАНР</option>
    ${GENRES.map(
      (genre) =>
        `<option value="${escapeHTML(genre)}">${escapeHTML(
          genre
        ).toUpperCase()}</option>`
    ).join("")}
  `;
}

export function populateGenreFilter(selectElement) {
  if (!selectElement) {
    return;
  }

  selectElement.innerHTML = `
    <option value="all">ВСЕ ЖАНРЫ</option>
    ${GENRES.map(
      (genre) =>
        `<option value="${escapeHTML(genre)}">${escapeHTML(
          genre
        ).toUpperCase()}</option>`
    ).join("")}
  `;
}

function getStatusLabel(status) {
  return BOOK_STATUSES[status]?.label || "Неизвестно";
}

function getBookProgress(book) {
  const progress = Number(book.progress);

  if (book.status === "read") {
    return 100;
  }

  if (book.status === "planned") {
    return 0;
  }

  return Math.min(100, Math.max(0, progress));
}

export function createBookCard(book) {
  const progress = getBookProgress(book);

  const card = document.createElement("article");

  card.className = "book-card";
  card.dataset.bookId = book.id;

  const readingProgress =
    book.status === "reading"
      ? `
        <div class="book-progress">
          <div class="progress-meta">
            <span>ПРОГРЕСС</span>
            <strong>${progress}%</strong>
          </div>

          <div class="progress-track">
            <div
              class="progress-fill"
              style="width: ${progress}%"
            ></div>
          </div>
        </div>
      `
      : "";

  card.innerHTML = `
    <div class="book-card-top">
      <span class="book-status">
        ${escapeHTML(getStatusLabel(book.status))}
      </span>

      <span class="book-id">
        ${escapeHTML(book.id.slice(0, 6).toUpperCase())}
      </span>
    </div>

    <div class="book-main">
      <h4 class="book-title">
        ${escapeHTML(book.title)}
      </h4>

      <p class="book-author">
        ${escapeHTML(book.author)}
      </p>

      <div class="book-details">
        <span>${escapeHTML(book.genre)}</span>
        <span>${Number(book.pages).toLocaleString("ru-RU")} стр.</span>
      </div>

      ${readingProgress}
    </div>

    <div class="book-actions">
      <button
        class="book-action"
        data-action="edit"
        type="button"
      >
        РЕД.
      </button>

      <button
        class="book-action"
        data-action="status"
        type="button"
      >
        СТАТУС
      </button>

      <button
        class="book-action book-action-danger"
        data-action="delete"
        type="button"
      >
        УДАЛИТЬ
      </button>
    </div>
  `;

  return card;
}

export function renderBooks(books, elements) {
  elements.readList.innerHTML = "";
  elements.readingList.innerHTML = "";
  elements.plannedList.innerHTML = "";

  const grouped = {
    read: [],
    reading: [],
    planned: []
  };

  books.forEach((book) => {
    if (grouped[book.status]) {
      grouped[book.status].push(book);
    }
  });

  grouped.read.forEach((book) => {
    elements.readList.appendChild(
      createBookCard(book)
    );
  });

  grouped.reading.forEach((book) => {
    elements.readingList.appendChild(
      createBookCard(book)
    );
  });

  grouped.planned.forEach((book) => {
    elements.plannedList.appendChild(
      createBookCard(book)
    );
  });

  elements.readCount.textContent = grouped.read.length;
  elements.readingCount.textContent = grouped.reading.length;
  elements.plannedCount.textContent = grouped.planned.length;

  elements.emptyState.classList.toggle(
    "hidden",
    books.length > 0
  );

  elements.booksCounter.textContent =
    `${books.length} ${getBookWord(books.length)}`;
}

function getBookWord(number) {
  const mod10 = number % 10;
  const mod100 = number % 100;

  if (mod10 === 1 && mod100 !== 11) {
    return "КНИГА";
  }

  if (
    mod10 >= 2 &&
    mod10 <= 4 &&
    (mod100 < 10 || mod100 >= 20)
  ) {
    return "КНИГИ";
  }

  return "КНИГ";
}

export function updateStatistics(books, elements) {
  const total = books.length;

  const read = books.filter(
    (book) => book.status === "read"
  ).length;

  let averageProgress = 0;

  if (total > 0) {
    const totalProgress = books.reduce(
      (sum, book) => {
        if (book.status === "read") {
          return sum + 100;
        }

        if (book.status === "planned") {
          return sum;
        }

        return sum + Number(book.progress || 0);
      },
      0
    );

    averageProgress = Math.round(
      totalProgress / total
    );
  }

  elements.totalBooks.textContent = total;
  elements.readBooks.textContent = read;
  elements.averageProgress.textContent =
    `${averageProgress}%`;
}

export function fillBookForm(book, elements) {
  elements.bookId.value = book.id;
  elements.bookTitle.value = book.title;
  elements.bookAuthor.value = book.author;
  elements.bookGenre.value = book.genre;
  elements.bookPages.value = book.pages;
  elements.bookStatus.value = book.status;
  elements.bookProgress.value = book.progress || 0;
  elements.progressValue.textContent =
    `${book.progress || 0}%`;

  updateProgressVisibility(elements);
}

export function clearBookForm(elements) {
  elements.bookForm.reset();

  elements.bookId.value = "";
  elements.bookProgress.value = "0";
  elements.progressValue.textContent = "0%";
  elements.bookStatus.value = "planned";

  updateProgressVisibility(elements);
}

export function updateProgressVisibility(elements) {
  const isReading =
    elements.bookStatus.value === "reading";

  elements.progressGroup.classList.toggle(
    "hidden",
    !isReading
  );

  if (!isReading) {
    elements.bookProgress.value =
      elements.bookStatus.value === "read"
        ? "100"
        : "0";

    elements.progressValue.textContent =
      elements.bookStatus.value === "read"
        ? "100%"
        : "0%";
  }
}

export function openModal(elements, editing = false) {
  elements.modalTitle.textContent = editing
    ? "РЕДАКТИРОВАТЬ КНИГУ"
    : "ДОБАВИТЬ КНИГУ";

  elements.bookModal.classList.remove("hidden");

  document.body.classList.add("modal-open");

  setTimeout(() => {
    elements.bookTitle.focus();
  }, 50);
}

export function closeModal(elements) {
  elements.bookModal.classList.add("hidden");

  document.body.classList.remove("modal-open");
}

export function showToast(message, type = "default") {
  const toast = document.getElementById("toast");

  if (!toast) {
    return;
  }

  toast.textContent = message;

  toast.className = "toast";

  if (type === "error") {
    toast.classList.add("toast-error");
  }

  requestAnimationFrame(() => {
    toast.classList.add("toast-visible");
  });

  clearTimeout(showToast.timeout);

  showToast.timeout = setTimeout(() => {
    toast.classList.remove("toast-visible");

    setTimeout(() => {
      toast.classList.add("hidden");
    }, 250);
  }, 2500);

  toast.classList.remove("hidden");
}